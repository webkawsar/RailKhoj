RAILKHOJ AUTOCOMPLETE INTEGRATION

1) Copy data/railway-cities.json to your Next.js project:
   data/railway-cities.json

2) Copy components/search/StationAutocomplete.tsx and StationAutocomplete.css to:
   components/search/StationAutocomplete.tsx
   components/search/StationAutocomplete.css

3) In app/search/page.tsx, add imports:
   import StationAutocomplete, { type RailwayCity } from "@/components/search/StationAutocomplete";
   import railwayCitiesData from "@/data/railway-cities.json";

4) Before SearchPage(), add:
   const railwayCities = railwayCitiesData as RailwayCity[];
   const defaultFrom = railwayCities.find((city) => city.city_name === "Dhaka") ?? null;
   const defaultTo = railwayCities.find((city) => city.city_name === "Sylhet") ?? null;

5) Replace the old from/to state declarations with:
   const [fromStation, setFromStation] = useState<RailwayCity | null>(defaultFrom);
   const [toStation, setToStation] = useState<RailwayCity | null>(defaultTo);
   const [fromInput, setFromInput] = useState(defaultFrom?.city_name.replace(/_/g, " ") ?? "");
   const [toInput, setToInput] = useState(defaultTo?.city_name.replace(/_/g, " ") ?? "");

6) Replace handleSwapStations() with:
   function handleSwapStations() {
     setFromStation(toStation);
     setToStation(fromStation);
     setFromInput(toInput);
     setToInput(fromInput);
     setMessage("");
   }

7) In handleSearch(), validate selected objects rather than text:
   if (!fromStation || !toStation || !journeyDate) {
     setMessage("Please select a valid starting station, destination, and journey date.");
     return;
   }
   if (fromStation.city_id === toStation.city_id) {
     setMessage("Starting and ending stations cannot be the same.");
     return;
   }
   // The selected IDs are available as fromStation.city_id and toStation.city_id.
   // Keep the remaining journey-date validation and pending-API message.

8) Replace the existing FROM field wrapper with:
   <StationAutocomplete
     label="FROM"
     placeholder="Starting station"
     inputValue={fromInput}
     onInputChange={setFromInput}
     selectedCity={fromStation}
     onSelect={setFromStation}
     fromOnly
   />

9) Replace the existing TO field wrapper with:
   <StationAutocomplete
     label="TO"
     placeholder="Destination station"
     inputValue={toInput}
     onInputChange={setToInput}
     selectedCity={toStation}
     onSelect={setToStation}
   />

10) Delete the old <datalist id="railway-stations">...</datalist> block.

The JSON file contains the 263 cities entries extracted from the supplied Railway configuration. The component shows up to 8 matching suggestions, supports keyboard navigation (Up/Down/Enter/Escape), and stores the selected city object including city_id. FROM is filtered by is_enable_for_from === 1. TO currently uses all entries because the supplied configuration only exposes the is_enable_for_from flag; destination eligibility should be adjusted if the Railway API reveals a separate rule.
