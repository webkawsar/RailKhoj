RailKhoj Search Results UI — Alternative Seat Search Action

Files:
- page.tsx
- ResultsPage.css

Install:
1. Copy page.tsx to app/search/results/page.tsx
2. Copy ResultsPage.css to app/search/results/ResultsPage.css
3. Keep the existing search flow storing the successful API response in sessionStorage under:
   railkhoj-search-result
4. The stored object should contain route (from, to, date) and data (API response).

What changed:
- Preserves the existing results page design and seat-availability cards.
- Adds a "Find Alternative Seats" action to every train card.
- If a train has 0 online seats, the action area gets a light-red priority treatment.
- Clicking the action saves the selected train and original route/date in sessionStorage under:
  railkhoj-alternative-search
- The action navigates to /search/results/alternatives.

Important:
The destination page at app/search/results/alternatives/page.tsx must be implemented to run the complex station-combination search. This change creates the UI and passes the selected train context; it does not yet perform the multi-segment API requests.

Seat count note:
The train-level online seat total is the sum of per-class online counts returned by the API.
