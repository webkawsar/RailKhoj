# RailKhoj train-routes API integration

## Files
- `app/api/train-route/route.ts` — server-side proxy to the Railway `POST /v1.0/web/train-routes` endpoint.
- `app/search/results/train/[trainId]/page.tsx` — updated page that recognizes `data.routes[]` and each station's `city` field.

## 1. Configure `.env.local`
Add fresh credentials (do not commit this file):

```env
RAILWAY_TOKEN=your_fresh_bearer_token_or_raw_token
RAILWAY_DEVICE_ID=your_device_id
RAILWAY_DEVICE_KEY=your_device_key
```

Restart the Next.js dev server after changing environment variables. The token from the user's earlier example was exposed in chat and should be refreshed; do not reuse it.

## 2. Expected request
The page calls:

`GET /api/train-route?model=769&date=2026-11-01`

The Next.js route forwards this as:

```json
{
  "model": "769",
  "departure_date_time": "2026-11-01"
}
```

## Important
The provided `train-routes` response contains the ordered route stations, not station-pair seat availability. This integration loads the route list. A separate search-trips API call is still needed for each station-to-station combination if you want actual seat counts.
