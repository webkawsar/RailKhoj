import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

const RAILWAY_ROUTE_URL = "https://railspaapi.shohoz.com/v1.0/web/train-routes";

function getAuthorizationHeader() {
  const configuredToken = process.env.RAILWAY_TOKEN?.trim();
  if (!configuredToken) return null;
  return configuredToken.toLowerCase().startsWith("bearer ")
    ? configuredToken
    : `Bearer ${configuredToken}`;
}

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const model = (searchParams.get("model") ?? searchParams.get("trainId") ?? "").trim();
  const departureDate = (searchParams.get("date") ?? "").trim();

  if (!model) {
    return NextResponse.json(
      { error: "Missing train model. Pass the train number/model in the model query parameter." },
      { status: 400 },
    );
  }

  if (!/^\d{4}-\d{2}-\d{2}$/.test(departureDate)) {
    return NextResponse.json(
      { error: "A valid journey date is required in YYYY-MM-DD format." },
      { status: 400 },
    );
  }

  const authorization = getAuthorizationHeader();
  const deviceId = process.env.RAILWAY_DEVICE_ID?.trim();
  const deviceKey = process.env.RAILWAY_DEVICE_KEY?.trim();

  if (!authorization || !deviceId || !deviceKey) {
    return NextResponse.json(
      { error: "Railway API credentials are not configured on the server." },
      { status: 500 },
    );
  }

  try {
    const upstreamResponse = await fetch(RAILWAY_ROUTE_URL, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: authorization,
        "x-device-id": deviceId,
        "x-device-key": deviceKey,
        "x-requested-with": "XMLHttpRequest",
        Origin: "https://eticket.railway.gov.bd",
        Referer: "https://eticket.railway.gov.bd/",
      },
      body: JSON.stringify({
        model,
        departure_date_time: departureDate,
      }),
      cache: "no-store",
    });

    const responseText = await upstreamResponse.text();
    let upstreamData: unknown;

    try {
      upstreamData = responseText ? JSON.parse(responseText) : null;
    } catch {
      upstreamData = { message: responseText || "Railway API returned an empty response." };
    }

    if (!upstreamResponse.ok) {
      return NextResponse.json(
        {
          error: "Railway API rejected the train-route request.",
          upstreamStatus: upstreamResponse.status,
          details: upstreamData,
        },
        { status: upstreamResponse.status },
      );
    }

    return NextResponse.json(
      {
        ok: true,
        upstreamStatus: upstreamResponse.status,
        data: upstreamData,
      },
      { status: 200 },
    );
  } catch {
    return NextResponse.json(
      { error: "Could not connect to the Railway train-routes API." },
      { status: 502 },
    );
  }
}
